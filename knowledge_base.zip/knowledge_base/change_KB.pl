%:- consult(change_KB_original).
:- consult(change_KB_extensions).
